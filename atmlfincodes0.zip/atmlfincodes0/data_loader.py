import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
import sentencepiece as spm
import tempfile
import os
import codecs

# Check for GPU and set device
if torch.cuda.is_available():
    device = torch.device('cuda')
    torch.backends.cudnn.benchmark = True
    print(f"Using GPU: {torch.cuda.get_device_name(0)}")
    print(f"GPU Memory: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.2f} GB")
else:
    device = torch.device('cpu')
    print("No GPU available, using CPU")

class TranslationDataset(Dataset):
    def __init__(self, source_texts, target_texts, source_tokenizer, target_tokenizer, max_length=50):
        self.source_texts = source_texts
        self.target_texts = target_texts
        self.source_tokenizer = source_tokenizer
        self.target_tokenizer = target_tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.source_texts)

    def __getitem__(self, idx):
        source_text = self.source_texts[idx]
        target_text = self.target_texts[idx]

        # Tokenize and convert to tensor
        source_tokens = self.source_tokenizer.encode_as_ids(source_text)
        target_tokens = self.target_tokenizer.encode_as_ids(target_text)

        # Pad sequences
        source_tokens = self._pad_sequence(source_tokens)
        target_tokens = self._pad_sequence(target_tokens)

        # Return CPU tensors - they will be moved to GPU in the training loop
        return {
            'source': torch.tensor(source_tokens, dtype=torch.long),
            'target': torch.tensor(target_tokens, dtype=torch.long)
        }

    def _pad_sequence(self, sequence):
        if len(sequence) < self.max_length:
            sequence = sequence + [0] * (self.max_length - len(sequence))
        else:
            sequence = sequence[:self.max_length]
        return sequence

def load_data(csv_path, train_ratio=0.8):
    
    print(f"Loading data from {r'english_assamese.csv'}")
    df = pd.read_csv(r'english_assamese.csv', encoding='utf-8')
    print(f"Total samples: {len(df)}")
    
    # Split into train and validation sets
    train_df, val_df = train_test_split(df, train_size=train_ratio, random_state=42)
    print(f"Training samples: {len(train_df)}")
    print(f"Validation samples: {len(val_df)}")
    
    return train_df, val_df

def create_tokenizers(train_df, vocab_size=8000):
    print("Creating tokenizers...")
    # Create temporary files for training data with UTF-8 encoding
    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt', encoding='utf-8') as source_file, \
         tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt', encoding='utf-8') as target_file:
        
        # Write source (English) text to temporary file
        for text in train_df['eng'].tolist():
            if isinstance(text, str):
                source_file.write(text + '\n')
        source_file_path = source_file.name
        
        # Write target (Assamese) text to temporary file
        for text in train_df['asm'].tolist():
            if isinstance(text, str):
                target_file.write(text + '\n')
        target_file_path = target_file.name
    
    try:
        print("Training English tokenizer...")
        # Train source tokenizer (English)
        source_model_prefix = 'english'
        spm.SentencePieceTrainer.train(
            input=source_file_path,
            model_prefix=source_model_prefix,
            vocab_size=vocab_size,
            model_type='bpe',
            input_sentence_size=1000000,
            shuffle_input_sentence=True,
            character_coverage=1.0,
            pad_id=0,
            unk_id=1,
            bos_id=2,
            eos_id=3
        )
        
        print("Training Assamese tokenizer...")
        # Train target tokenizer (Assamese)
        target_model_prefix = 'assamese'
        spm.SentencePieceTrainer.train(
            input=target_file_path,
            model_prefix=target_model_prefix,
            vocab_size=vocab_size,
            model_type='bpe',
            input_sentence_size=1000000,
            shuffle_input_sentence=True,
            character_coverage=1.0,
            pad_id=0,
            unk_id=1,
            bos_id=2,
            eos_id=3
        )
        
        # Load the trained tokenizers
        source_tokenizer = spm.SentencePieceProcessor()
        source_tokenizer.load(f'{source_model_prefix}.model')
        
        target_tokenizer = spm.SentencePieceProcessor()
        target_tokenizer.load(f'{target_model_prefix}.model')
        
        print("Tokenizers created successfully!")
        return source_tokenizer, target_tokenizer
    
    finally:
        # Clean up temporary files
        os.unlink(source_file_path)
        os.unlink(target_file_path)

if __name__ == "__main__":
    # Test the data loader
    print("\nTesting data loader...")
    train_df, val_df = load_data('your_dataset.csv')
    source_tokenizer, target_tokenizer = create_tokenizers(train_df)
    
    # Create a small test dataset
    test_dataset = TranslationDataset(
        train_df['eng'][:5].tolist(),
        train_df['asm'][:5].tolist(),
        source_tokenizer,
        target_tokenizer
    )
    
    print("\nTesting batch creation...")
    test_loader = DataLoader(test_dataset, batch_size=2, shuffle=True)
    for batch in test_loader:
        print(f"Source shape: {batch['source'].shape}")
        print(f"Target shape: {batch['target'].shape}")
        print(f"Device: {batch['source'].device}")
        break 