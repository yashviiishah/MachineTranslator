import torch
from model_attention import Encoder, Decoder, Seq2Seq
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction

def plot_attention(attention, source, target, src_vocab, trg_vocab):
    # Convert attention weights to numpy array
    attention = attention.squeeze(1).cpu().numpy()
    
    # Get source and target tokens
    src_tokens = [list(src_vocab.keys())[list(src_vocab.values()).index(i)] for i in source if i not in [src_vocab['<sos>'], src_vocab['<eos>'], src_vocab['<pad>']]]
    trg_tokens = [list(trg_vocab.keys())[list(trg_vocab.values()).index(i)] for i in target if i not in [trg_vocab['<sos>'], trg_vocab['<eos>'], trg_vocab['<pad>']]]
    
    # Create figure and axis
    fig = plt.figure(figsize=(10, 10))
    ax = fig.add_subplot(111)
    
    # Plot attention matrix
    cax = ax.matshow(attention, cmap='viridis')
    fig.colorbar(cax)
    
    # Set up axes
    ax.set_xticklabels([''] + src_tokens, rotation=90)
    ax.set_yticklabels([''] + trg_tokens)
    
    # Show every tick
    ax.xaxis.set_major_locator(ticker.MultipleLocator(1))
    ax.yaxis.set_major_locator(ticker.MultipleLocator(1))
    
    plt.title('Attention Map')
    plt.xlabel('Source Tokens')
    plt.ylabel('Target Tokens')
    plt.tight_layout()
    plt.savefig('attention_map.png')
    plt.close()

def translate_sentence(sentence, src_vocab, trg_vocab, model, device, max_len=50, plot_attention_map=False):
    model.eval()
    
    # Tokenize and convert to indices
    tokens = [src_vocab.get(token, src_vocab['<unk>']) for token in sentence]
    tokens = [src_vocab['<sos>']] + tokens + [src_vocab['<eos>']]
    
    # Convert to tensor
    src_tensor = torch.LongTensor(tokens).unsqueeze(0).to(device)
    
    # Get encoder outputs and hidden states
    with torch.no_grad():
        encoder_outputs, hidden, cell = model.encoder(src_tensor)
    
    # Initialize target sequence with <sos> token
    trg_indexes = [trg_vocab['<sos>']]
    attention_weights = []
    
    for i in range(max_len):
        trg_tensor = torch.LongTensor([trg_indexes[-1]]).to(device)
        
        with torch.no_grad():
            output, hidden, cell, attn_weights = model.decoder(trg_tensor, hidden, cell, encoder_outputs)
        
        attention_weights.append(attn_weights)
        pred_token = output.argmax(1).item()
        trg_indexes.append(pred_token)
        
        if pred_token == trg_vocab['<eos>']:
            break
    
    # Convert indices to tokens
    trg_tokens = [list(trg_vocab.keys())[list(trg_vocab.values()).index(i)] for i in trg_indexes]
    
    # Plot attention map if requested
    if plot_attention_map:
        attention_matrix = torch.cat(attention_weights, dim=1)
        plot_attention(attention_matrix, tokens, trg_indexes, src_vocab, trg_vocab)
    
    return trg_tokens[1:]  # Remove <sos> token

def calculate_bleu_score(reference, candidate):
    # Using NLTK's BLEU score implementation
    smooth = SmoothingFunction().method1
    return sentence_bleu([reference], candidate, smoothing_function=smooth)

def evaluate_model(model, test_loader, src_vocab, trg_vocab, device):
    model.eval()
    total_bleu = 0
    n_samples = 0
    
    with torch.no_grad():
        for batch in test_loader:
            src = batch[0]
            trg = batch[1]
            
            for i in range(src.shape[0]):
                # Get source sentence
                src_sentence = [list(src_vocab.keys())[list(src_vocab.values()).index(j.item())] 
                              for j in src[i] if j.item() not in [src_vocab['<sos>'], src_vocab['<eos>'], src_vocab['<pad>']]]
                
                # Get target sentence
                trg_sentence = [list(trg_vocab.keys())[list(trg_vocab.values()).index(j.item())] 
                              for j in trg[i] if j.item() not in [trg_vocab['<sos>'], trg_vocab['<eos>'], trg_vocab['<pad>']]]
                
                # Get model translation
                translation = translate_sentence(src_sentence, src_vocab, trg_vocab, model, device, plot_attention_map=(n_samples == 0))
                
                # Calculate BLEU score
                bleu = calculate_bleu_score(trg_sentence, translation)
                
                total_bleu += bleu
                n_samples += 1
                
                # Print first few examples with their BLEU scores
                if n_samples <= 3:
                    print(f"\nExample {n_samples}:")
                    print(f"Source: {' '.join(src_sentence)}")
                    print(f"Target: {' '.join(trg_sentence)}")
                    print(f"Translation: {' '.join(translation)}")
                    print(f"BLEU Score: {bleu:.4f}")
    
    return total_bleu / n_samples

if __name__ == "__main__":
    # Hyperparameters
    INPUT_DIM = 10000  # Replace with your vocabulary size
    OUTPUT_DIM = 10000  # Replace with your vocabulary size
    HIDDEN_DIM = 256
    N_LAYERS = 2
    DROPOUT = 0.2
    
    # Initialize model
    enc = Encoder(INPUT_DIM, HIDDEN_DIM, N_LAYERS, DROPOUT)
    dec = Decoder(OUTPUT_DIM, HIDDEN_DIM, N_LAYERS, DROPOUT)
    model = Seq2Seq(enc, dec)
    
    # Move model to GPU if available
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = model.to(device)
    
    # Load trained model
    model.load_state_dict(torch.load('attention_model.pt'))
    
    # Initialize your vocabularies and test loader here
    # src_vocab = ...
    # trg_vocab = ...
    # test_loader = ...
    
    # Evaluate model
    # bleu_score = evaluate_model(model, test_loader, src_vocab, trg_vocab, device)
    # print(f'\nAverage BLEU Score: {bleu_score:.4f}')
    
    # Example translation with attention visualization
    # test_sentence = "This is a test sentence"
    # translation = translate_sentence(test_sentence.split(), src_vocab, trg_vocab, model, device, plot_attention_map=True)
    # print(f'Translation: {" ".join(translation)}') 